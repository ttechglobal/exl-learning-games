"use client";

import { getElementByAtomicNumber } from "@/motion/periodicTableData";
import { CATEGORY_COLORS } from "@/motion/periodicTableData";
import { Mascot } from "@/motion/Mascot";
import type { MissionRow } from "@/types/db";
import styles from "@/app/(player)/play/[gameSlug]/EntryScreen.module.css";

export interface EntryScreenProps {
  gameTitle: string;
  subject: string;
  mission: MissionRow;
  onStart: () => void;
}

/**
 * Entry/mission-card screen: illustrated backdrop, the mascot greeting the
 * student in its idle pose, a staged materialize-in sequence (title ->
 * mascot -> card), and — when the mission's payload reports a proton target
 * (the soft contract any particle-assembly-style game can opt into) — a
 * small periodic-table-style glyph previewing the target element before the
 * student even starts. "You're about to build Carbon-14" should feel
 * different from "you're about to build Hydrogen," and this is the first
 * moment that difference shows up.
 */
export function EntryScreen({ gameTitle, subject, mission, onStart }: EntryScreenProps) {
  const target = (mission.payload as { target?: Record<string, number> }).target;
  const protonCount = target?.proton;
  const element = typeof protonCount === "number" ? getElementByAtomicNumber(protonCount) : undefined;
  const accentColor = element ? CATEGORY_COLORS[element.category] : "#7b4fcb";

  return (
    <div className={styles.wrap} style={{ "--accent-color": accentColor } as React.CSSProperties}>
      <img src="/mascot/scene-backdrop.svg" alt="" role="presentation" className={styles.backdrop} />

      <div className={styles.title}>{gameTitle.toUpperCase()}</div>
      <div className={styles.subtitle}>{subject}</div>

      <div className={styles.mascotRow}>
        <Mascot pose="idle" widthPx={130} />
      </div>

      <div className={styles.card}>
        <div className={styles.cardTopRow}>
          <div className={styles.cardLabel}>Today&apos;s Challenge</div>
          {element && (
            <div className={styles.elementGlyph}>
              <span className={styles.elementGlyphNumber}>{element.atomicNumber}</span>
              <span className={styles.elementGlyphSymbol}>{element.symbol}</span>
            </div>
          )}
        </div>
        <div className={styles.missionTitle}>{mission.title}</div>
        <div className={styles.metaRow}>
          <span>
            Reward: <b>+{mission.xp_reward} XP</b>
          </span>
          <span>Difficulty: {mission.difficulty}</span>
        </div>
        <button className={styles.startButton} onClick={onStart}>
          Start Mission
        </button>
      </div>
    </div>
  );
}
