"use client";

import { useState, useMemo } from "react";
import { GameRuntime } from "@/components/runtime/GameRuntime";
import { EntryScreen } from "@/app/(player)/play/[gameSlug]/EntryScreen";
import { LevelSelectScreen } from "@/app/(player)/play/[gameSlug]/LevelSelectScreen";
import type { GameRow, MissionRow } from "@/types/db";

export interface PlayClientProps {
  studentId: string;
  game: GameRow;
  missions: MissionRow[];
  initialMissionId: string;
}

type Screen = "levelSelect" | "entry" | "runtime";

/**
 * Owns the entry/mission-card screen, the (optional) level-select screen,
 * and which mission is currently active.
 *
 * Level select only shows for games whose missions represent genuinely
 * different LEVELS rather than a content sequence within one continuous
 * difficulty — Atom Forge's 4 missions are real levels (different
 * mechanics/difficulty: ionic, covalent, mixed, timed factory), so the
 * player picks one; Build The Atom's missions are all EASY/MEDIUM content
 * variety at the same difficulty tier, so it stays a straight linear
 * sequence with no picker. Detected by whether mission difficulty actually
 * varies across the list — a real signal already in the data, rather than
 * adding a separate "isLevelBased" config flag that would need its own
 * plumbing through content JSON for every future game.
 */
export function PlayClient({ studentId, game, missions, initialMissionId }: PlayClientProps) {
  const sortedMissions = useMemo(() => [...missions].sort((a, b) => a.sequence_index - b.sequence_index), [missions]);
  const isLevelBased = useMemo(() => new Set(sortedMissions.map((m) => m.difficulty)).size > 1, [sortedMissions]);

  const [screen, setScreen] = useState<Screen>(isLevelBased ? "levelSelect" : "entry");
  const [activeMissionId, setActiveMissionId] = useState(initialMissionId);

  const activeMissionIndex = sortedMissions.findIndex((m) => m.id === activeMissionId);
  const activeMission = sortedMissions[activeMissionIndex];
  const nextMission = sortedMissions[activeMissionIndex + 1];

  if (!activeMission) {
    return (
      <div style={{ textAlign: "center", padding: 60, color: "var(--eg-text-dim)" }}>Mission not found.</div>
    );
  }

  if (screen === "levelSelect") {
    return (
      <LevelSelectScreen
        gameTitle={game.title}
        missions={sortedMissions}
        onSelect={(missionId) => {
          setActiveMissionId(missionId);
          setScreen("entry");
        }}
      />
    );
  }

  if (screen === "entry") {
    return (
      <EntryScreen
        gameTitle={game.title}
        subject={game.subject}
        mission={activeMission}
        onStart={() => setScreen("runtime")}
      />
    );
  }

  // screen === 'runtime'
  return (
    <GameRuntime
      gameId={game.id}
      studentId={studentId}
      engineType={game.engine_type}
      sharedConfig={game.shared_config}
      snapshot={game.snapshot}
      mission={{
        id: activeMission.id,
        missionKey: activeMission.mission_key,
        title: activeMission.title,
        xpReward: activeMission.xp_reward,
        topicId: activeMission.topic_id,
        subtopicId: activeMission.subtopic_id ?? undefined,
        payload: activeMission.payload
      }}
      hasNextMission={Boolean(nextMission) && !isLevelBased}
      reviewSuccessLines={[
        `You successfully created ${(activeMission.payload as { resultLabel?: string }).resultLabel ?? activeMission.title}.`,
        "Review the Concept Snapshot any time from this screen."
      ]}
      onAdvanceToNextMission={() => {
        if (isLevelBased) {
          // Level-based games return to the level picker rather than
          // auto-advancing to a "next" level — completing Level 1 doesn't
          // imply Level 2 is what the player wants next.
          setScreen("levelSelect");
        } else if (nextMission) {
          setActiveMissionId(nextMission.id);
          setScreen("entry");
        }
      }}
    />
  );
}