"use client";

import Link from "next/link";
import { DepthBackdrop } from "@/motion/DepthBackdrop";
import type { GameRow } from "@/types/db";

export interface WorldsClientProps {
  bySubject: Record<string, GameRow[]>;
}

const SUBJECT_ACCENTS: Record<string, string> = {
  chemistry: "#00e5ff",
  biology: "#b6ff3c",
  physics: "#ff3cf0",
  mathematics: "#ffa63c"
};

export function WorldsClient({ bySubject }: WorldsClientProps) {
  const subjects = Object.entries(bySubject);
  const primaryAccent = subjects.length > 0 ? SUBJECT_ACCENTS[subjects[0][0]] ?? "#00e5ff" : "#00e5ff";

  return (
    <div style={{ position: "relative", minHeight: "100vh", padding: "60px 24px", maxWidth: 920, margin: "0 auto", overflow: "hidden" }}>
      <DepthBackdrop accentColor={primaryAccent} />
      <h1 style={{ position: "relative", zIndex: 1, fontFamily: "var(--eg-font-display)", fontSize: "2rem", marginBottom: 32 }}>
        Worlds
      </h1>
      {subjects.map(([subject, subjectGames]) => {
        const accent = SUBJECT_ACCENTS[subject] ?? "#00e5ff";
        return (
          <section key={subject} style={{ position: "relative", zIndex: 1, marginBottom: 40 }}>
            <h2
              style={{
                fontFamily: "var(--eg-font-display)",
                fontSize: "1.1rem",
                textTransform: "uppercase",
                letterSpacing: "0.1em",
                color: accent,
                marginBottom: 16
              }}
            >
              {subject}
            </h2>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 16 }}>
              {subjectGames.map((game) => (
                <Link
                  key={game.id}
                  href={`/play/${game.slug}`}
                  style={{
                    display: "block",
                    background: "var(--eg-glass)",
                    border: "1px solid var(--eg-glass-border)",
                    borderRadius: 14,
                    padding: 20,
                    color: "var(--eg-text-bright)",
                    textDecoration: "none",
                    boxShadow: `0 0 0 0 transparent`,
                    transition: "transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease"
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = "translateY(-2px)";
                    e.currentTarget.style.boxShadow = `0 0 24px color-mix(in srgb, ${accent} 30%, transparent)`;
                    e.currentTarget.style.borderColor = `color-mix(in srgb, ${accent} 50%, transparent)`;
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "translateY(0)";
                    e.currentTarget.style.boxShadow = "0 0 0 0 transparent";
                    e.currentTarget.style.borderColor = "var(--eg-glass-border)";
                  }}
                >
                  <div style={{ fontFamily: "var(--eg-font-display)", fontWeight: 600 }}>{game.title}</div>
                </Link>
              ))}
            </div>
          </section>
        );
      })}
      {subjects.length === 0 && (
        <p style={{ position: "relative", zIndex: 1, color: "var(--eg-text-dim)" }}>
          No games yet — seed the database to see them here.
        </p>
      )}
    </div>
  );
}
