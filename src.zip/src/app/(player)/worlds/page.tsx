import { listGames } from "@/lib/db/queries/games";
import { WorldsClient } from "@/app/(player)/worlds/WorldsClient";
import type { GameRow } from "@/types/db";

// Needs a live DB connection per-request; not meaningful to prerender at build time.
export const dynamic = "force-dynamic";

export default async function WorldsPage() {
  const games = await listGames();
  const bySubject = games.reduce<Record<string, GameRow[]>>((acc, game) => {
    (acc[game.subject] ??= []).push(game);
    return acc;
  }, {});

  return <WorldsClient bySubject={bySubject} />;
}
