"use client";

import { useState } from "react";
import Link from "next/link";
import { Mascot, type MascotPose } from "@/motion/Mascot";
import type { GameRow } from "@/types/db";
import styles from "@/app/HomePage.module.css";

const SUBJECTS: { key: string; name: string; emoji: string; color: string }[] = [
  { key: "chemistry", name: "Chemistry", emoji: "\u269B\uFE0F", color: "#7b4fcb" },
  { key: "mathematics", name: "Mathematics", emoji: "\u{1F4D0}", color: "#2f9bd6" },
  { key: "biology", name: "Biology", emoji: "\u{1F343}", color: "#4caf6e" },
  { key: "physics", name: "Physics", emoji: "\u269F\uFE0F", color: "#ff6f91" }
];

const GAME_CARD_ART: Record<string, string> = {
  "atom-forge": "/mascot/card-atom-forge.svg",
  "element-hunter": "/mascot/card-element-hunter.svg"
};

const GAME_CARD_DESC: Record<string, string> = {
  "atom-forge": "Bond atoms together and repair the machine that builds the world's materials.",
  "element-hunter": "Race the clock to spot elements by atomic number, group, and valence electrons."
};

export interface HomePageProps {
  gamesBySubject: Record<string, GameRow[]>;
  featuredGames: GameRow[];
}

export function HomePage({ gamesBySubject, featuredGames }: HomePageProps) {
  const [mascotPose, setMascotPose] = useState<MascotPose>("idle");
  const [reacting, setReacting] = useState(false);

  function reactTo(pose: MascotPose) {
    setMascotPose(pose);
    setReacting(true);
    setTimeout(() => setReacting(false), 260);
  }

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <img className={styles.heroBackdrop} src="/mascot/hero-backdrop.svg" alt="" />
        <div className={styles.heroContent}>
          <div className={`${styles.mascotStage} ${reacting ? styles.reacting : ""}`}>
            <Mascot pose={mascotPose} widthPx={190} />
          </div>
          <div className={styles.signageBanner}>
            <div className={styles.heroEyebrow}>WAEC &middot; JAMB &middot; NECO Exam Prep</div>
            <h1 className={styles.heroTitle}>
              Learn by <span className={styles.accent}>playing</span>, not memorizing
            </h1>
            <p className={styles.heroSubtitle}>
              Real games built around the topics that actually show up on your exam &mdash; bond atoms, hunt elements,
              and master concepts your textbook can&apos;t teach this well.
            </p>
            <div className={styles.heroCtas}>
              <Link
                href="/worlds"
                className={styles.heroPrimaryBtn}
                onMouseEnter={() => reactTo("celebrate")}
                onMouseLeave={() => setMascotPose("idle")}
              >
                Start Playing
              </Link>
              <a href="#worlds" className={styles.heroSecondaryBtn}>
                Browse Subjects
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.section} id="worlds">
        <div className={styles.sectionHeading}>
          <div className={styles.sectionTitle}>Choose Your World</div>
          <div className={styles.sectionSubtitle}>Each subject is its own world of games</div>
        </div>
        <div className={styles.worldGrid}>
          {SUBJECTS.map((subject) => {
            const games = gamesBySubject[subject.key] ?? [];
            const isLive = games.length > 0;
            const card = (
              <div
                className={`${styles.worldCard} ${isLive ? "" : styles.locked}`}
                style={{ "--card-color": subject.color } as React.CSSProperties}
                onMouseEnter={() => isLive && reactTo("idle")}
              >
                <div className={styles.worldIconWrap}>{subject.emoji}</div>
                <div className={styles.worldName}>{subject.name}</div>
                {isLive ? (
                  <div className={styles.worldCount}>
                    {games.length} game{games.length === 1 ? "" : "s"}
                  </div>
                ) : (
                  <div className={styles.worldComingSoon}>Coming soon</div>
                )}
              </div>
            );
            return isLive ? (
              <Link key={subject.key} href={`/worlds#${subject.key}`} style={{ textDecoration: "none" }}>
                {card}
              </Link>
            ) : (
              <div key={subject.key}>{card}</div>
            );
          })}
        </div>
      </section>

      {featuredGames.length > 0 && (
        <section className={styles.section}>
          <div className={styles.sectionHeading}>
            <div className={styles.sectionTitle}>Featured Games</div>
            <div className={styles.sectionSubtitle}>Jump straight in</div>
          </div>
          <div className={styles.gameGrid}>
            {featuredGames.map((game) => {
              const subjectColor = SUBJECTS.find((s) => s.key === game.subject)?.color ?? "#7b4fcb";
              return (
                <Link
                  key={game.id}
                  href={`/play/${game.slug}`}
                  className={styles.gameCard}
                  style={{ "--card-color": subjectColor } as React.CSSProperties}
                  onMouseEnter={() => reactTo("celebrate")}
                  onMouseLeave={() => setMascotPose("idle")}
                >
                  <img className={styles.gameCardArt} src={GAME_CARD_ART[game.slug] ?? ""} alt="" />
                  <div className={styles.gameCardBody}>
                    <div className={styles.gameCardSubject}>{game.subject}</div>
                    <div className={styles.gameCardTitle}>{game.title}</div>
                    <div className={styles.gameCardDesc}>{GAME_CARD_DESC[game.slug] ?? ""}</div>
                  </div>
                </Link>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}
