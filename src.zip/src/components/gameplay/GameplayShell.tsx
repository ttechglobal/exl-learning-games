"use client";

import styles from "@/components/gameplay/GameplayShell.module.css";

export interface GameplayStat {
  label: string;
  value: string | number;
  tone?: "default" | "danger" | "success" | "gold";
  /** Pulses the value — used for "time running out" urgency, but generic
   *  enough for any stat that needs the same emphasis. */
  urgent?: boolean;
  /** Small secondary line under the value — tile-match's streak/tier text,
   *  optional for engines with nothing to put there. */
  caption?: string;
}

export interface GameplayShellProps {
  /** Full-page environment background — see docs/ELEMENT_HUNTER_ENVIRONMENT_BRIEF.md
   *  for the asset spec this expects. Falls back to fallbackGradient
   *  (a CSS value, not a class) when missing/erroring, same pattern each
   *  engine used individually before this shell existed. */
  environmentImageSrc?: string;
  fallbackGradient: string;
  accentColor: string;
  /** Declarative HUD cards — NOT a fixed Time/Score pair. tile-match has
   *  Time + Score + streak/tier; particle-assembly has none; bond-match's
   *  level mode has only XP, factory mode adds Time. Each engine declares
   *  whatever stats it actually has; the shell only handles layout
   *  (spacing, responsive wrap, never overlapping the menu corner). */
  stats: GameplayStat[];
  /** Optional banner below the HUD — tile-match's clue text, bond-match's
   *  "Forge This Compound" + formula. Omit entirely for an engine with
   *  nothing prompt-shaped to show (e.g. particle-assembly, where the
   *  target composition is shown directly in the gameplay area instead). */
  missionPrompt?: { label: string; text: string };
  /** The in-game menu instance (see components/runtime/GameMenu.tsx) —
   *  rendered BY the shell in a fixed, reserved corner, so it can never
   *  visually collide with the stats row the way the old per-engine
   *  absolute-positioned HUD + fixed-positioned menu button used to
   *  (this was a real, confirmed bug: both claimed the same top-left
   *  corner). The shell owns menu placement; engines never position
   *  their own menu button again. */
  menu: React.ReactNode;
  /** True while paused — shell renders the dimmed "Paused" overlay
   *  centrally now, rather than each engine re-implementing the same
   *  overlay (tile-match previously did; bond-match/particle-assembly
   *  hadn't yet, which would have meant inconsistent pause UX per
   *  engine as more engines adopted isPaused). */
  isPaused?: boolean;
  /** The actual gameplay-specific interactive content — tile grid,
   *  bond-match's platform/dock, particle-assembly's generators. This is
   *  the ONLY part of the screen that's meant to look different from one
   *  game to the next; everything else above is shared chrome. */
  children: React.ReactNode;
}

/** Explicit map from tone -> styles.* class, not a dynamic
 *  `styles[someComputedKey]` lookup — same reasoning as the badge-class
 *  and difficulty-tier fixes elsewhere in this codebase: CSS Modules
 *  class names are hashed/typed, so building the key as a string at
 *  runtime is fragile even when the union is closed. */
const TONE_CLASS: Record<NonNullable<GameplayStat["tone"]>, string> = {
  default: "",
  danger: styles.statDanger,
  success: styles.statSuccess,
  gold: styles.statGold
};

/**
 * components/gameplay/GameplayShell.tsx
 *
 * The "master template for every game" (product brief). Owns: full-page
 * environment background, the stats/HUD row, an optional mission-prompt
 * banner, the in-game menu's fixed position, the pause overlay, and a
 * responsive content frame for whatever the engine renders inside. Every
 * engine (bond-match, particle-assembly, tile-match) now renders ONLY its
 * own gameplay-specific markup as `children`; HUD/menu/environment markup
 * that used to be duplicated (and drifting — e.g. only tile-match had a
 * pause overlay) inside each engine's own render is gone from there and
 * lives here once.
 *
 * Mobile-first responsive: a single-column stack below ~600px (stats row
 * wraps, gameplay content gets full width), a wider two-zone layout above
 * that where stats sit beside the mission prompt instead of stacking, and
 * a capped max-width on large desktop so the gameplay area never
 * stretches into uncomfortable reading/reach distance on big monitors —
 * see the brief's explicit "tablets, laptops, large desktop monitors"
 * requirement, which the old single 480px breakpoint never addressed.
 */
export function GameplayShell({
  environmentImageSrc,
  fallbackGradient,
  accentColor,
  stats,
  missionPrompt,
  menu,
  isPaused,
  children
}: GameplayShellProps) {
  return (
    <div className={styles.shell} style={{ "--accent-color": accentColor, "--fallback-gradient": fallbackGradient } as React.CSSProperties}>
      {environmentImageSrc && (
        <img
          src={environmentImageSrc}
          alt=""
          role="presentation"
          className={styles.environmentBackdrop}
          onError={(e) => {
            (e.currentTarget as HTMLImageElement).style.display = "none";
          }}
        />
      )}

      {isPaused && (
        <div className={styles.pausedOverlay}>
          <span className={styles.pausedLabel}>⏸ Paused</span>
        </div>
      )}

      {/* Menu lives in its own reserved corner, ALWAYS — this is what
          fixes the original "menu overlapping the timer" bug. Stats sit
          in their own row below it (or beside it at wider breakpoints),
          never sharing the same fixed-position corner the way a
          per-engine fixed menu button + absolute-positioned HUD used to. */}
      <div className={styles.menuSlot}>{menu}</div>

      <div className={styles.topZone}>
        <div className={styles.statsRow}>
          {stats.map((stat, i) => (
            <div key={i} className={styles.statCard}>
              <div className={styles.statLabel}>{stat.label}</div>
              <div className={[styles.statValue, TONE_CLASS[stat.tone ?? "default"], stat.urgent ? styles.urgent : ""].filter(Boolean).join(" ")}>
                {stat.value}
              </div>
              {stat.caption && <div className={styles.statCaption}>{stat.caption}</div>}
            </div>
          ))}
        </div>

        {missionPrompt && (
          <div className={styles.missionBanner}>
            <div className={styles.missionLabel}>{missionPrompt.label}</div>
            <div className={styles.missionText}>{missionPrompt.text}</div>
          </div>
        )}
      </div>

      <div className={styles.gameplayFrame}>{children}</div>
    </div>
  );
}