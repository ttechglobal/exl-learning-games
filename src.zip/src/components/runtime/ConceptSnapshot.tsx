"use client";

import { useEffect, useState } from "react";
import { primeAudioOnUserGesture } from "@/motion/sound/playSound";
import { Mascot } from "@/motion/Mascot";

export interface ConceptSnapshotProps {
  lines: string[];
  readTimeSec: number;
  onContinue: () => void;
  accentColor?: string;
}

/** "Before Play" briefing — 20-60s per the product brief, no quiz, just orientation. */
export function ConceptSnapshot({ lines, readTimeSec, onContinue, accentColor = "#7b4fcb" }: ConceptSnapshotProps) {
  const [secondsLeft, setSecondsLeft] = useState(readTimeSec);

  useEffect(() => {
    if (secondsLeft <= 0) return;
    const timer = setTimeout(() => setSecondsLeft((s) => s - 1), 1000);
    return () => clearTimeout(timer);
  }, [secondsLeft]);

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: 24 }}>
      <div style={{ marginBottom: -14 }}>
        <Mascot pose="idle" widthPx={96} />
      </div>
      <div
        style={{
          width: "min(460px, 90vw)",
          textAlign: "center",
          background: "#ffffff",
          border: `3px solid ${accentColor}`,
          borderRadius: 22,
          padding: 28,
          boxShadow: "0 10px 0 rgba(0,0,0,0.05), 0 14px 30px rgba(43,28,74,0.1)"
        }}
      >
        <div
          style={{
            fontSize: "0.72rem",
            letterSpacing: "0.16em",
            textTransform: "uppercase",
            color: accentColor,
            fontWeight: 700,
            marginBottom: 14
          }}
        >
          Quick Concept Snapshot
        </div>
        <div style={{ marginBottom: 22 }}>
          {lines.map((line, i) => (
            <div key={i} style={{ fontSize: "1.05rem", lineHeight: 1.7, marginBottom: 6, color: "var(--eg-text-bright)" }}>
              {line}
            </div>
          ))}
        </div>
        <div style={{ fontSize: "0.78rem", color: "var(--eg-text-dim)", marginBottom: 18 }}>
          Read time: {readTimeSec}s
        </div>
        <button
          onClick={() => {
            primeAudioOnUserGesture();
            onContinue();
          }}
          style={{
            width: "100%",
            minHeight: 54,
            borderRadius: 14,
            border: "none",
            background: accentColor,
            color: "#ffffff",
            fontFamily: "var(--eg-font-display)",
            fontWeight: 700,
            fontSize: "1.05rem",
            cursor: "pointer",
            boxShadow: `0 5px 0 color-mix(in srgb, ${accentColor} 70%, black)`
          }}
        >
          Continue
        </button>
      </div>
    </div>
  );
}
