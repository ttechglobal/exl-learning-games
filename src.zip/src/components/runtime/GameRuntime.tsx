"use client";

import { useState, useCallback } from "react";
import { ConceptSnapshot } from "@/components/runtime/ConceptSnapshot";
import { ReflectionScreen } from "@/components/runtime/ReflectionScreen";
import { PeriodicTableReveal } from "@/motion/PeriodicTableReveal";
import { getEngineDefinition } from "@/engines/registry";
import type { AttemptResult } from "@/types/result";
import { enqueueAttempt } from "@/lib/offline/attemptQueue";

export interface GameRuntimeMission {
  id: string;
  missionKey: string;
  title: string;
  xpReward: number;
  topicId: string;
  subtopicId?: string;
  payload: Record<string, unknown>;
}

export interface GameRuntimeProps {
  gameId: string;
  studentId: string;
  engineType: string;
  sharedConfig: Record<string, unknown>;
  snapshot: { lines: string[]; readTimeSec: number };
  mission: GameRuntimeMission;
  hasNextMission: boolean;
  reviewSuccessLines: string[];
  onAdvanceToNextMission: () => void;
}

type Phase = "snapshot" | "playing" | "reflection";

/**
 * Orchestrates the full per-mission loop (architecture doc Section 3.1):
 * Concept Snapshot -> mount the right engine via registry.ts -> receive raw
 * outcome -> build AttemptResult -> POST /api/attempts (or queue offline) ->
 * Reflection screen.
 *
 * This component is the SAME for every game — it contains no subject- or
 * engine-specific logic. Each engine just needs to call onComplete with its
 * own outcome shape; this component normalizes whatever comes back into the
 * platform-wide AttemptResult before sending it anywhere.
 */
export function GameRuntime({
  gameId,
  studentId,
  engineType,
  sharedConfig,
  snapshot,
  mission,
  hasNextMission,
  reviewSuccessLines,
  onAdvanceToNextMission
}: GameRuntimeProps) {
  const [phase, setPhase] = useState<Phase>("snapshot");
  const [lastResult, setLastResult] = useState<AttemptResult | null>(null);

  const engineDef = getEngineDefinition(engineType);

  const handleEngineComplete = useCallback(
    async (rawOutcome: Record<string, unknown>) => {
      const result: AttemptResult = {
        studentId,
        gameId,
        missionId: mission.id,
        topicId: mission.topicId,
        subtopicId: mission.subtopicId,
        success: typeof rawOutcome.success === "boolean" ? rawOutcome.success : undefined,
        score: typeof rawOutcome.score === "number" ? rawOutcome.score : undefined,
        timeSpentSec: typeof rawOutcome.timeSpentSec === "number" ? rawOutcome.timeSpentSec : undefined,
        attemptsBeforeSuccess:
          typeof rawOutcome.attemptsBeforeSuccess === "number" ? rawOutcome.attemptsBeforeSuccess : undefined,
        rawOutcome,
        completedAt: new Date().toISOString()
      };

      setLastResult(result);
      setPhase("reflection");

      try {
        const response = await fetch("/api/attempts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(result)
        });
        if (!response.ok) throw new Error(`POST /api/attempts failed: ${response.status}`);
      } catch {
        // Offline or the request otherwise failed — queue it; attemptQueue
        // flushes to the active ExportAdapter once connectivity returns.
        // The student still sees their Reflection screen immediately either way.
        await enqueueAttempt(result);
      }
    },
    [studentId, gameId, mission]
  );

  if (phase === "snapshot") {
    return (
      <ConceptSnapshot
        lines={snapshot.lines}
        readTimeSec={snapshot.readTimeSec}
        onContinue={() => setPhase("playing")}
      />
    );
  }

  if (phase === "playing") {
    if (!engineDef) {
      return (
        <div style={{ color: "var(--eg-danger)", textAlign: "center", padding: 40 }}>
          No engine registered for type &quot;{engineType}&quot;. Check src/engines/registry.ts.
        </div>
      );
    }
    const EngineComponent = engineDef.Component;
    return (
      <EngineComponent
        config={{ shared: sharedConfig, mission }}
        onComplete={(outcome: unknown) => handleEngineComplete(outcome as Record<string, unknown>)}
      />
    );
  }

  // phase === 'reflection'
  // Soft, optional contract: ANY engine reporting `finalComposition.proton` in
  // its raw outcome gets the periodic table reveal automatically — this isn't
  // hardcoded to particle-assembly by name, it's keyed on the shape of the
  // data. An engine with no notion of "proton count" simply won't trigger it.
  const finalComposition = lastResult?.rawOutcome?.finalComposition as Record<string, number> | undefined;
  const protonCount = finalComposition?.proton;

  return (
    <ReflectionScreen
      successLines={reviewSuccessLines}
      hasNextMission={hasNextMission}
      onPlayAgain={() => setPhase("playing")}
      onNextMission={onAdvanceToNextMission}
      onViewConceptSummary={() => setPhase("snapshot")}
      extraContent={typeof protonCount === "number" ? <PeriodicTableReveal highlightAtomicNumber={protonCount} /> : undefined}
    />
  );
}
