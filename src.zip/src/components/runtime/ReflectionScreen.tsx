"use client";

import { Mascot } from "@/motion/Mascot";

export interface ReflectionScreenProps {
  successLines: string[];
  hasNextMission: boolean;
  onPlayAgain: () => void;
  onNextMission: () => void;
  onViewConceptSummary: () => void;
  accentColor?: string;
  /**
   * Optional slot for game/engine-specific reveal content (e.g. the
   * chemistry-only PeriodicTableReveal). Kept generic here on purpose —
   * ReflectionScreen is shared across every engine, so anything specific to
   * one subject's visuals is injected by the caller (GameRuntime / the page),
   * not hardcoded into this component.
   */
  extraContent?: React.ReactNode;
}

/** "After Play" reflection — per the product brief: review, play again, practice questions. */
export function ReflectionScreen({
  successLines,
  hasNextMission,
  onPlayAgain,
  onNextMission,
  onViewConceptSummary,
  accentColor = "#7b4fcb",
  extraContent
}: ReflectionScreenProps) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: 24 }}>
      <div style={{ marginBottom: -22 }}>
        <Mascot pose="celebrate" widthPx={140} />
      </div>
      <div
        style={{
          width: "min(460px, 90vw)",
          textAlign: "center",
          background: "#ffffff",
          border: `3px solid ${accentColor}`,
          borderRadius: 22,
          padding: 28,
          paddingTop: 36,
          boxShadow: "0 10px 0 rgba(0,0,0,0.05), 0 14px 30px rgba(43,28,74,0.1)"
        }}
      >
        <div style={{ fontFamily: "var(--eg-font-display)", fontWeight: 700, fontSize: "1.3rem", marginBottom: 16, color: "var(--eg-text-bright)" }}>
          Mission Complete!
        </div>
        {successLines.map((line, i) => (
          <div key={i} style={{ fontSize: "0.98rem", lineHeight: 1.7, marginBottom: 4, color: "var(--eg-text-bright)" }}>
            {line}
          </div>
        ))}
        {extraContent}
        <div style={{ marginTop: 22, display: "flex", flexDirection: "column", gap: 10 }}>
          <button
            disabled={!hasNextMission}
            onClick={onNextMission}
            style={{
              width: "100%",
              minHeight: 54,
              borderRadius: 14,
              border: "none",
              background: hasNextMission ? accentColor : "#d8d2e8",
              color: "#ffffff",
              fontFamily: "var(--eg-font-display)",
              fontWeight: 700,
              fontSize: "1.05rem",
              cursor: hasNextMission ? "pointer" : "default",
              boxShadow: hasNextMission ? `0 5px 0 color-mix(in srgb, ${accentColor} 70%, black)` : "none"
            }}
          >
            {hasNextMission ? "Next Mission" : "All Missions Complete"}
          </button>
          <button
            onClick={onPlayAgain}
            style={{
              width: "100%",
              minHeight: 48,
              borderRadius: 14,
              border: `2px solid ${accentColor}`,
              background: "transparent",
              color: accentColor,
              fontFamily: "var(--eg-font-display)",
              fontWeight: 600,
              fontSize: "0.92rem",
              cursor: "pointer"
            }}
          >
            Play Again
          </button>
          <button
            onClick={onViewConceptSummary}
            style={{
              width: "100%",
              minHeight: 48,
              borderRadius: 14,
              border: "none",
              background: "transparent",
              color: "var(--eg-text-dim)",
              fontSize: "0.88rem",
              cursor: "pointer",
              textDecoration: "underline"
            }}
          >
            View Concept Summary
          </button>
        </div>
      </div>
    </div>
  );
}
