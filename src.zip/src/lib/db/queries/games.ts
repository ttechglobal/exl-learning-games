import { supabaseServer } from "@/lib/db/supabase";
import type { GameRow, MissionRow } from "@/types/db";

export async function getGameBySlug(slug: string): Promise<GameRow | null> {
  const { data, error } = await supabaseServer()
    .from("game")
    .select("*")
    .eq("slug", slug)
    .eq("is_active", true)
    .single();

  if (error) {
    if (error.code === "PGRST116") return null; // no rows
    throw error;
  }
  return data as GameRow;
}

export async function getGameById(id: string): Promise<GameRow | null> {
  const { data, error } = await supabaseServer().from("game").select("*").eq("id", id).single();
  if (error) {
    if (error.code === "PGRST116") return null;
    throw error;
  }
  return data as GameRow;
}

export async function listGames(filters: { subject?: string; topicId?: string } = {}): Promise<GameRow[]> {
  let query = supabaseServer().from("game").select("*").eq("is_active", true);
  if (filters.subject) query = query.eq("subject", filters.subject);
  if (filters.topicId) query = query.eq("topic_id", filters.topicId);

  const { data, error } = await query;
  if (error) throw error;
  return (data ?? []) as GameRow[];
}

export async function getMissionsForGame(gameId: string): Promise<MissionRow[]> {
  const { data, error } = await supabaseServer()
    .from("mission")
    .select("*")
    .eq("game_id", gameId)
    .eq("is_active", true)
    .order("sequence_index", { ascending: true });

  if (error) throw error;
  return (data ?? []) as MissionRow[];
}

export async function getMissionById(id: string): Promise<MissionRow | null> {
  const { data, error } = await supabaseServer().from("mission").select("*").eq("id", id).single();
  if (error) {
    if (error.code === "PGRST116") return null;
    throw error;
  }
  return data as MissionRow;
}
