/**
 * Hand-mirrored types for the Supabase schema (supabase/migrations/0001_init.sql).
 *
 * There's no ORM generating these from the schema (we dropped Prisma for the
 * Supabase JS client + SQL migrations), so these must be kept in sync by hand
 * whenever a migration changes a table shape. Column names are snake_case to
 * match Postgres directly; mapping to camelCase (if desired) happens in
 * lib/db/queries/*, not here.
 */

export type Difficulty = "EASY" | "MEDIUM" | "HARD";

export interface GameRow {
  id: string;
  slug: string;
  title: string;
  engine_type: string;
  subject: string;
  topic_id: string;
  subtopic_id: string | null;
  shared_config: Record<string, unknown>;
  snapshot: { lines: string[]; readTimeSec: number };
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface MissionRow {
  id: string;
  game_id: string;
  mission_key: string;
  title: string;
  difficulty: Difficulty;
  sequence_index: number;
  xp_reward: number;
  topic_id: string;
  subtopic_id: string | null;
  payload: Record<string, unknown>;
  is_active: boolean;
}

export interface StudentRow {
  id: string;
  external_id: string | null;
  display_name: string;
  xp_total: number;
  created_at: string;
}

export interface AttemptRow {
  id: string;
  student_id: string;
  game_id: string;
  mission_id: string | null;
  topic_id: string;
  subtopic_id: string | null;
  success: boolean | null;
  score: number | null;
  time_spent_sec: number | null;
  attempts_before_success: number | null;
  xp_awarded: number;
  raw_outcome: Record<string, unknown>;
  completed_at: string;
}

export interface TopicProgressRow {
  id: string;
  student_id: string;
  topic_id: string;
  subtopic_id: string | null;
  mastery_score: number;
  attempts_count: number;
  is_mastered: boolean;
  updated_at: string;
}

/** Shape passed to supabase-js's generic typing, e.g. supabase.from<GameRow>('game') */
export interface Database {
  game: GameRow;
  mission: MissionRow;
  student: StudentRow;
  attempt: AttemptRow;
  topic_progress: TopicProgressRow;
}
